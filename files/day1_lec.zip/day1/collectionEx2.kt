package day1

fun main() {
    val ldata:List<Any> = listOf("hello", true, 2000)
    println(ldata)
    //ldata[2] = 4000

    val ldata2:MutableList<Any> = mutableListOf("hello", true, 2000)
    ldata2[2] = 5000
    println(ldata2)
    ldata2.set(0, "bye")
    ldata2.add(1, 3232.323f)
    println(ldata2)
}