package day1

fun main() {
    val mdata1 = mapOf<String, Any>(Pair("name", "kim"), Pair("age",20))
    println(mdata1)
    println(mdata1["age"])
    println(mdata1.get("age"))
    //mdata1["name"] = "oh"

    val mdata2 = mutableMapOf<String, Any>(Pair("name", "kim"), Pair("age",20))
    mdata2["name"] = "oh"
    println(mdata2)
    mdata2.set("age", 40)
    println(mdata2)
    mdata2.put("weight", 60)
    println(mdata2)
    mdata2["city"] = "seoul"
    println(mdata2)
}