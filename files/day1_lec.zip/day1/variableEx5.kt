package day1

fun main() {
    val a1:Int = 10
    var a2:Double = a1.toDouble()
    var a3:Float = a1.toFloat()
    var a4:String = a1.toString()

    println(a1)
    println(a2)
    println(a3)
    println(a4 is String)
}