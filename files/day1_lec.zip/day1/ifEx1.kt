package day1

fun main() {
    val a = 15

    if(a <15){
        println("a<10")
    }else if(a > 0 && a<=10){
        println("a >0 && a<= 10")
    }else{
        println("a > 10")
    }
}