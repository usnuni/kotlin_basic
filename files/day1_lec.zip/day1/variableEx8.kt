package day1

fun main() {
    //var data1:Int = null
    //val data2:Int = null

    var data3:Int? = null
    var data4:Int? = null
    println(data3)
    println(data4)
    data3 = 100
    data4 = 200
    println(data3)
    println(data4)

    var data5:Any? = null
    data5 = 3232.332f
    println(data5)
    println("$data3 $data4")

}