package day1

fun main() {
    var sum:Int = 0
    for (i in 1 .. 5)
        println(i)
    println()

    for (i in 1 .. 11 step 2)
        println(i)

    println()
    for(i in 1 until 11 step 2)
        println(i)
}