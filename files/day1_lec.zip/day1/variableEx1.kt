package day1

fun main(args: Array<String>) {
    var var1 = 10
    println(var1)

    var var2:Int = 100
    println(var2)

    var var3:Float = 3232.32f
    var var4:Long = 1000L
    var var5:String = "Hello kotlin"
    var var6:Double = 3323.32323
    var var7:Boolean = true

    println(var3)
    println(var4)
    println(var5)
    println(var6)
    println(var7)
}