package day1

fun main() {
    var data1 = Array<Int>(3,{0})
    println(data1[0])
    println(data1[1])
    println(data1[2])
    data1[0] = 10
    data1[1] = 20
    data1[2] = 30
    println(data1[0])
    println(data1[1])
    println(data1[2])
    println()

    var data2 = Array<Int>(3, {i -> (i+1) * 100})
    println(data2[0])
    println(data2[1])
    println(data2[2])
    println()

    var data3 = intArrayOf(4,5,6,7)
    println(data3[2])
    println(data3.get(2))
    println(data3.size)
    data3[0] = 100
    println(data3[0])
    data3.set(1,200)
    println(data3[1])

    val data4 = arrayOf("cat", 10, 32232.32f)
    println(data4[0])
    println(data4[1])
    println(data4[2])
    println()

    val animal = arrayOf<String>("cat", "dog", "turtle")
    println(animal[0])
    println(animal[1])
    println(animal[2])

    var arrlist = ArrayList<Int>(4)
    arrlist.add(10)
    arrlist.add(20)
    arrlist.add(20)
    arrlist.add(20)
    arrlist.add(20)
    println(arrlist)
    println(arrlist.get(1))
    println(arrlist[1])
    println(arrlist[2])
    println(arrlist[3])
    println(arrlist[4])
}