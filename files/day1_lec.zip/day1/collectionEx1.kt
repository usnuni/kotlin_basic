package day1

fun main() {
    var arr1 = arrayOfNulls<Any>(3)
    println(arr1[0])
    arr1[0] = "kim"
    arr1[1] = 100
    arr1[2] = false

    for(data in arr1)
        println(data)
}