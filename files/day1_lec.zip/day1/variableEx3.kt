package day1

val topData1:Int = 100
var topData2:Int = 200

class User{
    val objData1:String ="hi"
    var objData2:String = "good"
    fun some(){
        val localData:Int
        var localData2:String

        localData = 100
        localData2 = "kim"

        println(localData)
        println(localData2)
    }
}

fun main(args: Array<String>) {
    val obj1 = User()
    obj1.some()
    println(topData1)
    println(topData2)
    println(obj1.objData1)
    println(obj1.objData2)
}
