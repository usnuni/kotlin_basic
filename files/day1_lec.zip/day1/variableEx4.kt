package day1

var myBool = false
val myVal:String = "hello good"
    get() {
        if (myBool)
            return field.uppercase()
        else
            return field
    }

fun main(args: Array<String>) {
    println(myVal)
    myBool = true
    println(myVal)
}
