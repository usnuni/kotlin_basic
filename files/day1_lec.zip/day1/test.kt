package day1

fun main(args:Array<String>){
    val data1 = 100
    println(data1)
    println("hello Kotlin!!!!!!")
}