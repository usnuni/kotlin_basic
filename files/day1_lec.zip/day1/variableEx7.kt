package day1

fun main() {
    val a : Any
    a = 4.3434f
    println(a)
    println(a.javaClass.name)

    val b : Any
    b = 323L
    println(b.javaClass.name)

    val c : Any
    c = true
    println(c)
    println(c.javaClass.name)
    println(c is Boolean)
}