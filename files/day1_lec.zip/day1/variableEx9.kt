package day1

fun main() {
    val myval1 : Any = 10
    val myval2 : Any? = myval1
    println(myval1)
    println(myval2)

    val myval3 : Any? = 20
    val myval4 : Any = myval3 as Any
    println(myval4)

    var data = "good day"
    println(data!!.split(" "))
}