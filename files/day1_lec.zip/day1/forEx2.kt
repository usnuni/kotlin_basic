package day1

fun main() {
    val arrData = arrayOf<String>("easy", "difficult", "hard")
    for(str in arrData)
        println(str)
    println()

    for(i in arrData.indices)
        println("index:$i value:${arrData[i]}")
    println()

    for((index, value) in arrData.withIndex())
        println("index:$index value:$value")

    for(i in 2 .. 9) {
        for (j in 1..9)
            println("$i * $j = ${i * j}")
        println()
    }
}