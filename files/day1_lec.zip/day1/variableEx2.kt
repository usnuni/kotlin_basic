package day1

fun main(args: Array<String>) {
    val data1:Int = 100
    var data2:Int = 200
    println(data1)
    println(data2)

    data2 = 3000
    println(data2)

    /*
    */

    //data1 = 1000
}