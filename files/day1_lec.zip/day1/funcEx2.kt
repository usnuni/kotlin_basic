package day1

fun sum4(a:Int, b:Int) = a + b
fun sum5(a:Int, b:Int):Int = a + b

fun main() {
    println(sum4(10, 20 ))
    println(sum5(10, 20 ))
}