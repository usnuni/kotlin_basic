package day1

fun main() {
    val sdata1 = setOf<String>("kim", "lee", "choi", "lee", "choi")
    println(sdata1)
    println(sdata1.elementAt(0))
    println(sdata1.elementAt(2))

    val sdata2 = mutableSetOf<String>("kim", "lee", "choi", "lee", "choi")
    sdata2.add("oh")
    sdata2.add("choi")
    println(sdata2)
    println()

    val sdata3 = setOf<Int>(1,2,3,4)
    val sdata4 = setOf<Int>(3,4,5,6)
    println(sdata3.union(sdata4))
    println(sdata3.intersect(sdata4))
    println(sdata3.subtract(sdata4))
}