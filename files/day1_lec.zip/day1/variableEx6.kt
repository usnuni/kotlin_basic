package day1

val str1:String = "Hello"
val str2:String = """
   안녕하세요
   good day
"""
var str3:String = "Hello"

fun main() {
    println(str1)
    println(str2)
    println(str3)
    str3 = str3 + " world"
    println(str3)
    println("string value:"+str3)
    println("string value:$str3")
    println(str3[1])
    println("string value:$str3[1]")
    println("string value:${str3[1]}")
}