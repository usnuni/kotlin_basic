package day1

fun main() {
    print("정수를 입력하세요:")
    val data1 = readLine()!!.toInt()
    println("input value: $data1")

    var data2:String = readLine()!!
    val sdata = data2.split(" ")
    println("split data:$sdata")
}