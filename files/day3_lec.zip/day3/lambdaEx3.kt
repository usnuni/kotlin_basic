package day3

fun vcFunc(x1:Int, x2:Int):Boolean{
    return x1 > x2
}

class AAA(val name:String, val age:Int)

fun main() {
    println(vcFunc(100, 50))

    val lambdaFunc1:(Int, Int) -> Boolean = {x1:Int, x2:Int -> x1 > x2}
    println(lambdaFunc1(100, 50))

    val lambdaFunc2:(Int, Int) -> Boolean = {x1, x2 -> x1 > x2}
    println(lambdaFunc2(100, 50))
    println()

    val lambdaV :(AAA) -> Int = {aaa:AAA -> aaa.age}
    println("lambdaV return:${lambdaV(AAA("kim", 30))}")

    val lambdaV2 :(AAA) -> Int = {it.age}
    println("lambdaV return:${lambdaV2(AAA("kim", 30))}")


    val lambdaV3 :(AAA) -> Int = AAA::age
    println("lambdaV return:${lambdaV3(AAA("kim", 30))}")

}