package day3

fun main() {
    val arr = arrayOf("hello", null, "lim")
    arr.forEach {
        if(it != null){
            println("$it, length:${it.length}")
        }
    }
    println()

    arr.forEach {
        it?.let {
            println("$it, length:${it.length}")
        }
    }
}