package day3

fun add(data1:Int, data2:Int){
    val result = data1 + data2
    println("add result:$result")
}

fun subtract(data1:Int, data2:Int){
    val result = data1 - data2
    println("subtract result:$result")
}

fun main() {
    val calcfunc1 = ::add
    println(calcfunc1)
    calcfunc1(100,200)

    val calcfunc2 = ::subtract
    calcfunc2(100, 50)
}