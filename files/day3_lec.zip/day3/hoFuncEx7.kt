package day3

class User{
    var name:String? = null
    var age:Int? = null

    fun sayHello(){
        println("Hello $name")
    }

    fun sayInfo(){
        println("i am $name, $age years old")
    }
}

fun main() {
    val result = run{
        println("lambda function call")
        10 * 20
    }
    println("result:$result")
    println()

    val user = User()
    user.name = "lim"
    user.age = 40
    user.sayHello()
    user.sayInfo()
    println()

    val result2 = user.run{
        name = "kim"
        age = 10
        sayHello()
        sayInfo()
        10 * 50
    }
    println("result2:$result2")
    println()

    var user2 = user.apply{
        name = "oh"
        age = 30
        sayHello()
        sayInfo()
    }
    println("user2 name:${user2.name}, user2.age:${user2.age}")
    println()

    var result3 = with(user){
        name = "lee"
        sayHello()
        sayInfo()
        30 + 50
    }
    println("result3:$result3")
    println()

    letTestFun(user)
    println()

    user.let{
        letTestFun(it)
        it.sayInfo()
        it.sayHello()
    }
    println()

    User2("kim", 50).let{
        letTestFun(it)
        it.sayInfo()
        it.sayHello()
    }
}

fun letTestFun(user:User){
    println("letTestFun():${user.name}, ${user.age}")
}

fun letTestFun(user:User2){
    println("letTestFun():${user.name}, ${user.age}")
}

class User2{
    var name:String? = null
    var age:Int? = null

    constructor(name:String, age:Int){
        this.name = name
        this.age = age
    }

    fun sayHello(){
        println("Hello $name")
    }

    fun sayInfo(){
        println("i am $name, $age years old")
    }
}
