package day3

fun addNumber(n1:Int, n2:Int):Int{
   return n1 + n2
}

fun main() {
    val result1 = addNumber(100, 200)
    println("result:$result1")

    val addNumber2 = {n1:Int, n2:Int -> n1 + n2}
    val result2 = addNumber2(100, 200)
    println("result2:$result2")
    println()

    val sum1 = {-> 10 + 20}
    println("sum1:${sum1()}")

    val sum2 = {10 + 20}
    println("sum2:${sum2()}")
    println()

    val sum3 = {x1:Int, x2:Int ->
        println("lambda func call")
        x1 + x2
    }
    println("sum3=${sum3(100,400)}")


}