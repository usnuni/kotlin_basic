package day3

var data1:String = "lim"
var data2:String? = null

fun main() {
    data2 = "hello"
    //val data3:String = data2!!
    val data3:String? = data2
    println("data3:${data3}")
}