package day3

import java.lang.Exception

fun main() {
    try{
        println("try top")
        val data:String = "lim"
        val intData:Int? = data.toInt()
        println("try bottom")
    }catch(e:Exception){
        println("catch")
        println(e.toString())
    }finally {
        println("finally")
    }
}