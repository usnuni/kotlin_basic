package day3

class MathUtil<T:Number>{
    fun plus(arg1:T, arg2:T):Double{
        return arg1.toDouble() + arg2.toDouble()
    }
}

fun main() {
    val obj = MathUtil<Int>()
    println(obj.plus(100, 200))

    val obj2 = MathUtil<Float>()
    println(obj2.plus(4232.323f, 4423.3f))

    //val obj3 = MathUtil<String>()
}