package day3

fun main() {
    var data1:String? = "lim"
    //val length:Int = data1.length
    val length1:Int? = if(data1 != null){
        data1.length
    }else{
        null
    }
    println("length:$length1")

    var length2:Int? = data1?.length
    println("length2:$length2")

    data1 = null
    length2 = data1?.length
    println(length2)
}