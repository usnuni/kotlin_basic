package day3

class MyClass3<T, A>{
    var info:T? = null
    var data:A? = null

    fun printInfo(){
        println("info:$info, data:$data")
    }

    fun myFunc(arg:T):A?{
        println("arg:$arg")
        return data
    }
}

fun main() {
    var obj1:MyClass3<String, Int> = MyClass3()
    obj1.info="hello"
    obj1.data = 400
    obj1.printInfo()
    println()

    var obj2 = MyClass3<Int, String>()
    obj2.info = 333
    obj2.data = "seoul"
    obj2.printInfo()

    println()
    println(obj1.myFunc("good day"))
}