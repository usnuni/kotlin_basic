package day3

fun main() {
    //var data:String? = "kim"
    var data:String? = null

    var length:Int = if(data!=null){
        data.length
    }else{
        -1
    }
    println("length:$length")

    length = data?.length?:-1
    println("length:$length")

    println()
    val strData:String = "kim"
    val intData :Int? = strData as? Int
    println(intData)
}