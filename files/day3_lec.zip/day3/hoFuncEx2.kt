package day3

fun main() {
    val arr = arrayOf(10,20,30,7,9,1,22,55)
    val fdata = arr.filter{x -> x > 10}
    println("fdata:$fdata")
    println()

    fdata.forEach{x -> println(x)}
    println()

    arr.filter{x -> x > 10}.forEach{x -> println(x)}

}