package day3

class MyClass<T>{
    var info:T? = null
}

fun main() {
    val obj1 = MyClass<String>()
    obj1.info = "hello"

    val obj2 = MyClass<Int>()
    obj2.info = 100

    println("obj1 info:${obj1.info}")
    println("obj2 info:${obj2.info}")
}