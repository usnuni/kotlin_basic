package day3

fun hofun(x1:Int, argFun:(Int) -> Int){
    val result = argFun(x1)
    println("x1:$x1, func result:$result")
}

fun main() {
    hofun(10, {x -> x * 5})
}