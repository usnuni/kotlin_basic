package day3

import java.lang.ArithmeticException

fun main() {
    var num1 = 100
    var num2 = 0

    try {
        println(num1 / num2)
    }catch (e:ArithmeticException){
        println("숫자는 0으로 나눌 수 없습니다.")
        println(e.toString())
    }

    println("program end")
}