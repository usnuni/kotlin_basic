package day3

fun callCalc():(x:Int) ->Int{
    return {x -> x * x}
}

fun callCalc2(str:String):(x1:Int, x2:Int)->Int{
    when(str){
        "+" -> return {x1, x2 -> x1 + x2}
        "-" -> return {x1, x2 -> x1 - x2}
        "*" -> return {x1, x2 -> x1 * x2}
        else -> return {x1, x2 -> x1 / x2}
    }
}

fun main() {
    val resultFun1 = callCalc()
    println("result:${resultFun1(20)}")

    val resultFunc2 = callCalc2("-")
    println("result2:${resultFunc2(50, 30)}")
}