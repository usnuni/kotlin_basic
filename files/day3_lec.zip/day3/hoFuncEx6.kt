package day3

inline fun hoFuncTest(argFun:(x1:Int, x2:Int)->Int){
    val result = argFun(10, 20)
    println("result:$result")
}

fun main() {
    hoFuncTest{x1, x2 -> x1 - x2}
}