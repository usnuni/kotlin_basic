package day3

import java.lang.ClassCastException
import java.lang.Exception

fun some(array:Array<Any>){
    try {
        println("top try")
        val intData: Int = array[0] as Int
        val data: String = array[2] as String
        val data2: Int = data.toInt()
    }catch(e:ClassCastException){
        println("classCastException")
    }catch(e:ArrayIndexOutOfBoundsException){
        println("arrayIndexOutOfBoundsException")
    }catch(e:Exception){
        println(e.toString())
    }
}

fun main() {
    val arr = arrayOf<Any>("0",1,"6")
    some(arr)
    println()

    val arr2 = arrayOf<Any>(10, 1)
    some(arr2)
    println()

    val arr3 = arrayOf<Any>(10, 1, "world")
    some(arr3)
}