package day3

class Address{
    val city:String = "seoul"
}

class User1{
    //val address:Address = Address()
    val address:Address? = null
}

fun main() {
    val user:User1 = User1()
    println(user.address?.city)

    val user2:User1? = null
    println(user2?.address?.city)
}