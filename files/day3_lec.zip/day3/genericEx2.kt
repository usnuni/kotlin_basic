package day3

class MyClass2<T>(no:T){
    var info:T? = null
}

fun main() {
    val obj1 = MyClass2(10)
    obj1.info = 200

    val obj2 = MyClass2("hello")
    obj2.info = "world"

    println("obj1 info:${obj1.info}")
    println("obj2 info:${obj2.info}")
}