package day3

open class Shape{
    var x:Int = 0
        set(value){
            if(value <0) field = 0
            else field = value
        }
    var y:Int = 0
        set(value){
            if(value < 0) field = 0
            else field = value
        }
    lateinit var name:String

    open fun printInfo(){
        println("name:$name, location:$x, $y")
    }
}

class Shape11{
    class Circle(val radius:Double):Shape(){
        override fun printInfo() {
            super.printInfo()
            println("radius:$radius")
        }
    }

    class Rect(val width:Int, val height:Int):Shape(){
        override fun printInfo() {
            super.printInfo()
            println("width:$width, height:$height")
        }
    }
}

fun main() {
    val shape1 = Shape11.Circle(10.0)
    shape1.x = 10
    shape1.y = 10
    shape1.name="circle"
    shape1.printInfo()
    println()

    val shape2 = Shape11.Rect(100,200)
    shape2.x = 20
    shape2.y = 30
    shape2.name="rect"
    shape2.printInfo()
}