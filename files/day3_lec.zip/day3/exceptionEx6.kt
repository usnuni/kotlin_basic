package day3

import java.lang.Exception

class MyException(msg:String):Exception(msg){
    val errorData:String = "some error Data"
    fun errorFun(){
        println("errorFun call....")
    }
}

fun some3(){
    throw MyException("MyException error!!!!")
}

fun main() {
    try{
        some3()
    }catch(e:MyException){
        println("error Message -> ${e.toString()}")
        println("error Data: ${e.errorData}")
        e.errorFun()
    }
}