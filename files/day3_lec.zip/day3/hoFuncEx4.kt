package day3

fun add2(data1:Int, data2:Int){
    val result = data1 + data2
    println("add result:$result")
}

fun subtract2(data1:Int, data2:Int){
    val result = data1 - data2
    println("subtract result:$result")
}

fun calc(data1:Int, data2:Int, operation:(Int, Int) -> Unit){
    operation(data1, data2)
}

fun main() {
    calc(100, 200, ::add2)
    calc(100, 200, ::subtract2)
}