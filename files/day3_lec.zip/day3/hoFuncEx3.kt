package day3

fun hoFun(
    x1:Int,
    argFunc1:(Int) -> Int,
    argFunc2:(Int) -> Boolean = {x:Int -> x > 10}
){
    val result = argFunc1(x1)
    println("result :${argFunc2(result)}")
}

fun main() {
    hoFun(2, {x:Int -> x * x}, {x:Int -> x > 20})
    hoFun(4, {x:Int -> x * x})
}