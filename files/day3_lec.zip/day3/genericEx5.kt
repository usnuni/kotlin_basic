package day3

interface MyInterface1
interface MyInterface2

class MyHandler1 : MyInterface1, MyInterface2

class MyHandler2 : MyInterface1

class MyClass5<T> where T:MyInterface1, T:MyInterface2{}
class MyClass5_2<T> where T:MyInterface1{}

fun main() {
    var obj = MyClass5<MyHandler1>()
    //var obj2 = MyClass5<MyHandler2>()
    var obj2 = MyClass5_2<MyHandler2>()
    var obj3 = MyClass5_2<MyHandler1>()

}