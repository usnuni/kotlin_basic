package day2

class User2(name:String, age:Int){
    var name = ""
    var age = 0
    init{
        this.name = name
        this.age = age
    }

    fun printInfo(){
        print("name:$name age:$age")
    }
}

fun main() {
    val obj1 = User2("lee", 30)
    obj1.printInfo()
}