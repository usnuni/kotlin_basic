package day2

abstract class Animal{
    var name :String = ""
    abstract fun move()
}

class Tiger:Animal(){
    var age :Int = 0
    override fun move() {
        println("네발로 이동한다.")
    }
}

class Eagle:Animal(){
    var size:Int = 0
    override fun move() {
        println("날개로 날아서 이동한다.")
    }
}

fun main() {
    val tiger = Tiger()
    val eagle = Eagle()

    tiger.move()
    eagle.move()

    var animal:Animal
    animal = Tiger()
    animal.move()

    animal = Eagle()
    animal.move()
}
