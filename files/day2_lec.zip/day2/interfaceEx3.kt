package day2

interface MyInterface3{
    var data1:Int

    var data2:Int
        set(value){
            if(value > 0)
                println(calData(value))
        }
        get() = calData(data1)

    fun calData(arg:Int):Int{
        return arg * arg
    }
}

class MyClass3:MyInterface3{
    override var data1:Int = 10
}

fun main() {
    val obj = MyClass3()
    println("data1:${obj.data1} data2:${obj.data2}")

    obj.data1 = 5
    obj.data2 = 100
    println("data1:${obj.data1} data2:${obj.data2}")
}