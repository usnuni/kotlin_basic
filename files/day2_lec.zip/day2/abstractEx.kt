package day2

abstract class Parent{
    val data1:Int = 0
    abstract val data2:Int

    fun myfunc1(){
        println("myfunc call")
    }
    abstract fun myfunc2()
}

class Child:Parent(){
    override val data2:Int = 20
    override fun myfunc2() {
        println("data1:$data1, data2:$data2")
    }
}

fun main() {
    val obj1 = Child()
    obj1.myfunc1()
    obj1.myfunc2()
}