package day2

class User11(var name1:String, var age1:Int)

class User12(var name2:String, var age2:Int){
    fun printInfo(){
        println("name:$name2, age:$age2")
    }
}

fun main() {
    val user1 = User11("kim", 10)
    println(user1.name1)
    println(user1.age1)

    val user2 = User12("lee", 40)
    user2.printInfo()
}
