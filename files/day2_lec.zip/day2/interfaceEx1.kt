package day2

interface MyInterface{
    var data1:String
    fun myFunc1()
}

interface MyInterface2{
    var data2:String
    fun myFunc2()
}

class MyClass2:MyInterface, MyInterface2{
    override var data1:String = "good day"
    override var data2:String = "hi everyone"

    override fun myFunc1() {
        println("data1:$data1")
    }

    override fun myFunc2() {
        println("data2:$data2")
    }
}

fun main() {
    val obj = MyClass2()
    obj.myFunc1()
    obj.myFunc2()
}