package day2

open class AAA{
    constructor(name:String, no:Int){
        println("AAA constructor call")
        println("name:$name, no:$no")
    }
}

class BBB:AAA{
    constructor(name:String, no:Int):super(name, no){
        println("BBB constructor call")
    }
}

class CCC(name:String, no:Int):AAA(name, no){
    init{
        println("CCC init call")
    }
}

fun main() {
    val bb = BBB("BBB", 10)
    println()
    val cc = CCC("CCC", 300)
}