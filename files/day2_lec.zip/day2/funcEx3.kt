package day2

fun some(a:String){
    println("some1 func call")
    println(a+"\n")
}

fun some(a:Int){
    println("some2 func call")
    println("$a \n")
}

fun some(a:Int, b:String){
    println("some3 func call")
    println("$a, $b \n")
}

fun main() {
    some("kim")
    some(200)
    some(500, "choi")
}