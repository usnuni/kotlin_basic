package day2

class User9{
    lateinit var lateData:String
}

fun main() {
    val user = User9()
    user.lateData = "hi everyone"
    println(user.lateData)
}

/*
1. lateinit는 var를 선언한 프로퍼티에서만 사용할 수 있다.
2. lateinit는 클래스 몸체에 선언한 프로퍼티에서만 사용할 수 있다(주 생성자에서는 사용할 수 없다)
3. null 허용 프로퍼티는 사용할 수 없다.
4. 기초 타입 프로퍼티는 사용할 수 없다.

 */