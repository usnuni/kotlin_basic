package day2

infix fun Int.myFun(x:Int):Int{
    return this * x
}

class FunClass{
    infix fun infixFun(a:Int):Int{
        return (a+10) * 20
    }
}

fun main() {
    println(20 myFun 50)
    println(20.myFun(50))

    var obj = FunClass()
    println(obj infixFun 200)
    println(obj.infixFun(200))
}