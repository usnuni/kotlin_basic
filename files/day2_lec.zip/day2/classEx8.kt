package day2

class User7{
    var data1:String
    var data2:Int

    init{
        data1 = "kim"
        data2 = 10
    }
}

fun main() {
    var user = User7()
    println("data1:${user.data1}, data2:${user.data2}")
}