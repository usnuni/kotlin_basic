package day2

fun sayHello(name:String){
    println("Hello $name")
}

fun sayHello2(name:String="hyo"){
    println("Hello $name!!!")
}

fun sayHello3(name:String="hyo", age:Int=10){
    println("Hello $name!!! age:$age")
}

fun sayHello4(name:String?){
    if(name == null)
        println("hello kim")
    else
        println("hello $name")
}

fun main() {
    sayHello("kim")
    sayHello2()
    sayHello2("lee")
    sayHello3()
    sayHello3("choi")
    sayHello3(age = 50)
    sayHello4(null)
    sayHello4("oh")
    sayHello4("oh")
}