package day2

fun add(data1:Int, data2:Int){
    val result = data1 + data2
    println("add result: $result")
}

fun add(vararg nums:Int){
    var sum = 0
    for(num in nums)
        sum += num
    println("add result2: $sum")
}

fun add(name:String, vararg nums:Int){
    var sum = 0
    for(num in nums)
        sum += num
    println("name:$name, add result2: $sum")
}

fun main() {
    add(100, 200)
    add(10,20,30)
    add(10,20,30,40,50)
    add("kcal", 100,200,300,400)
}