package day2

abstract class Animal2{
    var name:String = ""
    abstract fun move()
}

interface iAnimal{
    fun eat()
}

class iEagle:Animal2(), iAnimal{
    override fun move() {
        println("날아서 이동한다.")
    }
    override fun eat() {
        println("물고기를 잡아서 먹는다.")
    }
}

class iTiger:Animal2(), iAnimal{
    override fun move() {
        println("네발로 이동한다.")
    }
    override fun eat() {
        println("멧돼지를 잡아서 먹는다.")
    }
}

fun main() {
    val eagle = iEagle()
    eagle.move()
    eagle.eat()
    println()

    val tiger = iTiger()
    tiger.move()
    tiger.eat()
}