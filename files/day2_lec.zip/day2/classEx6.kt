package day2

class User4{
    var name:String = "kim"
        set(value){
            field = value
        }
        get(){
            return field.uppercase()
        }

    var age:Int = 20
        set(value){
            if(value > 0)
                field = value
            else
                field = 0
        }
        get() = field
}

fun main() {
    val obj1 = User4()
    obj1.name = "lee"
    obj1.age = -40
    println("name:${obj1.name}")
    println("age:${obj1.age}")
}