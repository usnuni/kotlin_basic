package day2

data class MyClass(val no:Int){
    operator fun plus(arg:Int):Int{
        return no + (arg * 2)
    }
}

operator fun MyClass.minus(arg:Int):Int{
    return no * 10 - (arg)
}

fun main() {
    val obj = MyClass(20)
    val result1 = obj + 5
    println("result1:$result1")

    val result2 = obj - 5
    println("result2:$result2")
}